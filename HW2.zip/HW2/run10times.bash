#!/bin/bash



for i in {1..10};
do
  python swarm.py
  python randomsearch.py
done
